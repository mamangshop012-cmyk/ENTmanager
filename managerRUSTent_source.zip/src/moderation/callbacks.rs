use sqlx::SqlitePool;

use crate::moderation::actions::modstatus::{self, DashboardPage};
use crate::moderation::callbackguard::guard_callback_query;
use crate::moderation::db as mod_db;

use teloxide::{
    prelude::*,
    types::{
        CallbackQuery, ChatId, ChatPermissions, InlineKeyboardButton, InlineKeyboardMarkup,
        ParseMode, UserId,
    },
};

/// ==========================================================
/// MAIN MODERATION CALLBACK HANDLER
/// ==========================================================
///
/// Semua callback moderation diproses di SATU tempat.
///
/// Read-only:
/// - modstatus:*
/// - modstatus:noop
///
/// Protected / mutating:
/// - appeal_*
/// - dismiss_warn_*
/// - approve_appeal_*
/// - reject_appeal_*
/// - confirm_reset_all_warn
/// - cancel_reset_all_warn
///
/// IMPORTANT:
/// `modstatus:*` TIDAK melakukan pengecekan admin ulang.
/// Authorization sudah dilakukan saat `/modstatus` melewati
/// PintuGuard sebelum dashboard dibuat.
///
/// Karena modstatus hanya READ-ONLY, callback cukup:
///
///     callback
///       ↓
///     ACK
///       ↓
///     edit dashboard
///
/// Tidak perlu `get_chat_member()` setiap pindah page.
///
pub async fn handle_moderation_callback(
    bot: Bot,
    q: CallbackQuery,
    pool: SqlitePool,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    // ======================================================
    // CALLBACK MASUK
    // ======================================================

    println!(
        "📩 [CALLBACK MASUK] id={} data={:?} from={} ({})",
        q.id, q.data, q.from.first_name, q.from.id
    );

    // ======================================================
    // CALLBACK DATA
    // ======================================================

    let data = match q.data.as_deref() {
        Some(data) => data,

        None => {
            println!("⚠️ [CALLBACK] Tidak ada callback_data");

            let _ = bot.answer_callback_query(q.id).await;

            return Ok(());
        }
    };

    println!("⚙️ [CALLBACK DATA] {}", data);

    // ======================================================
    // MESSAGE
    // ======================================================

    let msg = match q.message.as_ref() {
        Some(message) => message,

        None => {
            println!("⚠️ [CALLBACK] Callback tidak mempunyai message");

            let _ = bot.answer_callback_query(q.id).await;

            return Ok(());
        }
    };

    let chat_id = msg.chat().id.0;
    let message_id = msg.id().0;
    let clicker_id = q.from.id.0 as i64;

    println!(
        "⚙️ [CALLBACK CONTEXT] chat={} message={} user={}",
        chat_id, message_id, clicker_id
    );

    // ==========================================================
    // ==========================================================
    // 1. MODSTATUS
    // ==========================================================
    // ==========================================================
    //
    // ⚡ OPTIMIZED READ-ONLY CALLBACK
    //
    // TIDAK:
    // - get_chat_member()
    // - callback guard
    // - permission check kedua
    //
    // Karena `/modstatus` sudah melewati PintuGuard
    // ketika command pertama kali dijalankan.
    //
    // Dashboard hanya membaca konfigurasi dan berpindah page.
    //
    // ==========================================================

    if data.starts_with("modstatus:") {
        // --------------------------------------------------
        // NOOP
        // --------------------------------------------------
        //
        // Tombol tengah:
        // "1 / 3"
        // "2 / 3"
        // "3 / 3"
        //
        // Tidak melakukan apa-apa.
        //

        if data == "modstatus:noop" {
            println!("ℹ️ [MODSTATUS] NOOP callback");

            let _ = bot.answer_callback_query(q.id).await;

            return Ok(());
        }

        // --------------------------------------------------
        // PARSE PAGE
        // --------------------------------------------------

        let page_number = data
            .strip_prefix("modstatus:")
            .unwrap_or("1")
            .parse::<i32>()
            .unwrap_or(1)
            .clamp(1, 3);

        let target_page = DashboardPage::from_number(page_number);

        println!(
            "📊 [MODSTATUS CALLBACK] requested={} target={}",
            page_number,
            target_page.number()
        );

        // --------------------------------------------------
        // ⚡ ACK CALLBACK SECEPAT MUNGKIN
        // --------------------------------------------------
        //
        // Ini membuat Telegram langsung tahu bahwa tombol
        // sudah diterima bot.
        //
        // Jangan taruh setelah query/database/edit.
        //

        if let Err(err) = bot.answer_callback_query(q.id.clone()).await {
            println!("⚠️ [MODSTATUS ACK ERROR] {:?}", err);
        }

        // --------------------------------------------------
        // 🚀 EDIT DASHBOARD
        // --------------------------------------------------

        println!(
            "🔄 [MODSTATUS] Editing chat={} message={} -> page={}",
            chat_id,
            message_id,
            target_page.number()
        );

        match modstatus::edit_modstatus_page(&bot, &pool, chat_id, message_id, target_page).await {
            Ok(_) => {
                println!(
                    "✅ [MODSTATUS] Berhasil pindah ke page {}",
                    target_page.number()
                );
            }

            Err(err) => {
                println!("❌ [MODSTATUS EDIT ERROR] {:?}", err);
            }
        }

        return Ok(());
    }

    // ==========================================================
    // ==========================================================
    // 2. CALLBACK GUARD
    // ==========================================================
    // ==========================================================
    //
    // Semua callback SELAIN modstatus tetap melewati
    // callback guard.
    //
    // Ini penting karena callback berikut melakukan
    // perubahan data / moderasi.
    //
    // ==========================================================

    if !guard_callback_query(&bot, &q).await? {
        println!("🛡️ [CALLBACK DITOLAK] guard_callback_query");

        return Ok(());
    }

    // ==========================================================
    // ==========================================================
    // 3. APPEAL
    // ==========================================================
    // ==========================================================

    if data.starts_with("appeal_") {
        println!("⚖️ [APPEAL] User {} mengajukan appeal", clicker_id);

        if mod_db::has_pending_appeal(&pool, chat_id, clicker_id).await? {
            let _ = bot
                .answer_callback_query(q.id)
                .text("⚠️ Banding Anda sedang ditinjau oleh Admin. Mohon tunggu.")
                .show_alert(true)
                .await;

            return Ok(());
        }

        let appeal_id =
            mod_db::create_appeal(&pool, chat_id, clicker_id, message_id as i64).await?;

        let settings = mod_db::get_or_create_warn_settings(&pool, chat_id).await?;

        // --------------------------------------------------
        // LOG CHANNEL
        // --------------------------------------------------

        if let Some(log_channel_id) = settings.log_channel_id {
            let clicker_name = &q.from.first_name;

            let appeal_card = format!(
                "⚖️ <b>PENGAJUAN BANDING \
                 (APPEAL #{appeal_id})</b>\n\n\
                 • <b>Grup ID:</b> <code>{chat_id}</code>\n\
                 • <b>User:</b> \
                 <a href=\"tg://user?id={clicker_id}\">\
                 {clicker_name}</a> \
                 (<code>{clicker_id}</code>)\n\
                 • <b>Status:</b> \
                 ⏳ Menunggu Keputusan Admin"
            );

            let keyboard = InlineKeyboardMarkup::new(vec![vec![
                InlineKeyboardButton::callback(
                    "✅ Setujui",
                    format!("approve_appeal_{}_{}", appeal_id, clicker_id),
                ),
                InlineKeyboardButton::callback("❌ Tolak", format!("reject_appeal_{}", appeal_id)),
            ]]);

            match bot
                .send_message(ChatId(log_channel_id), appeal_card)
                .parse_mode(ParseMode::Html)
                .reply_markup(keyboard)
                .await
            {
                Ok(sent_msg) => {
                    let _ =
                        mod_db::update_appeal_log_msg(&pool, appeal_id, sent_msg.id.0 as i64).await;
                }

                Err(err) => {
                    println!("❌ [APPEAL LOG ERROR] {:?}", err);
                }
            }
        }

        let _ = bot
            .answer_callback_query(q.id)
            .text(
                "✅ Pengajuan banding Anda \
                 telah dikirimkan ke Admin!",
            )
            .show_alert(true)
            .await;

        return Ok(());
    }

    // ==========================================================
    // ==========================================================
    // 4. DISMISS WARN
    // ==========================================================
    // ==========================================================

    if data.starts_with("dismiss_warn_") {
        let target_user_id: i64 = data
            .strip_prefix("dismiss_warn_")
            .unwrap_or("0")
            .split(':')
            .next()
            .unwrap_or("0")
            .parse()
            .unwrap_or(0);

        let new_warn = mod_db::decrement_user_warn(&pool, chat_id, target_user_id).await?;

        let admin_name = &q.from.first_name;

        bot.edit_message_text(
            msg.chat().id,
            msg.id(),
            format!(
                "✅ <b>Peringatan Dibatalkan!</b>\n\
                 Admin <b>{admin_name}</b> telah \
                 menghapus peringatan untuk user \
                 <code>{target_user_id}</code>.\n\
                 Sisa Warn: <code>{new_warn}</code>"
            ),
        )
        .parse_mode(ParseMode::Html)
        .await?;

        let _ = bot
            .answer_callback_query(q.id)
            .text("✅ Peringatan berhasil dihapus!")
            .await;

        return Ok(());
    }

    // ==========================================================
    // ==========================================================
    // 5. APPROVE APPEAL
    // ==========================================================
    // ==========================================================

    if data.starts_with("approve_appeal_") {
        let clean_data = data.strip_prefix("approve_appeal_").unwrap_or("");

        let parts: Vec<&str> = clean_data.split('_').collect();

        if parts.len() >= 2 {
            let appeal_id: i64 = parts[0].parse().unwrap_or(0);

            let appeal_info: Option<(i64, i64)> = sqlx::query_as(
                "SELECT chat_id, user_id \
                     FROM warn_appeals \
                     WHERE id = ?",
            )
            .bind(appeal_id)
            .fetch_optional(&pool)
            .await
            .unwrap_or(None);

            if let Some((group_chat_id, user_id)) = appeal_info {
                let target_id = UserId(user_id as u64);

                let admin_name = &q.from.first_name;

                let member = bot.get_chat_member(ChatId(group_chat_id), target_id).await;

                let is_restricted = match &member {
                    Ok(member) => member.is_restricted(),

                    Err(_) => false,
                };

                let action_text: String;

                if is_restricted {
                    let _ = bot
                        .restrict_chat_member(
                            ChatId(group_chat_id),
                            target_id,
                            ChatPermissions::all(),
                        )
                        .await;

                    action_text = "Pembungkaman (Mute) \
                         telah dicabut."
                        .to_string();
                } else {
                    let new_warn = mod_db::decrement_user_warn(&pool, group_chat_id, user_id)
                        .await
                        .unwrap_or(0);

                    action_text = format!(
                        "1 Poin Warn dihapus \
                             (Sisa Warn: \
                             <code>{new_warn}</code>)."
                    );
                }

                mod_db::update_appeal_status(&pool, appeal_id, "approved").await?;

                bot.edit_message_text(
                    msg.chat().id,
                    msg.id(),
                    format!(
                        "✅ <b>Appeal #{appeal_id} \
                         DISETUJUI oleh \
                         {admin_name}.</b>\n\
                         • Status: {action_text}"
                    ),
                )
                .parse_mode(ParseMode::Html)
                .await?;

                let user_link = format!(
                    "<a href=\"tg://user?id={}\">\
                         User</a>",
                    user_id
                );

                let _ = bot
                    .send_message(
                        ChatId(group_chat_id),
                        format!(
                            "⚖️ <b>Banding Disetujui!</b>\n\
                             Banding untuk {} telah \
                             disetujui Admin \
                             {admin_name}.\n\
                             • Status: {action_text}",
                            user_link
                        ),
                    )
                    .parse_mode(ParseMode::Html)
                    .await;
            }
        }

        let _ = bot.answer_callback_query(q.id).await;

        return Ok(());
    }

    // ==========================================================
    // ==========================================================
    // 6. REJECT APPEAL
    // ==========================================================
    // ==========================================================

    if data.starts_with("reject_appeal_") {
        let appeal_id: i64 = data
            .strip_prefix("reject_appeal_")
            .unwrap_or("0")
            .split('_')
            .next()
            .unwrap_or("0")
            .parse()
            .unwrap_or(0);

        mod_db::update_appeal_status(&pool, appeal_id, "rejected").await?;

        bot.edit_message_text(
            msg.chat().id,
            msg.id(),
            format!(
                "❌ <b>Appeal #{appeal_id} \
                 DITOLAK.</b>"
            ),
        )
        .parse_mode(ParseMode::Html)
        .await?;

        let _ = bot.answer_callback_query(q.id).await;

        return Ok(());
    }

    // ==========================================================
    // ==========================================================
    // 7. RESET ALL WARNS
    // ==========================================================
    // ==========================================================

    if data.starts_with("confirm_reset_all_warn") {
        let _ = bot.answer_callback_query(q.id.clone()).await;

        match mod_db::reset_all_warns(&pool, chat_id).await {
            Ok(_) => {
                let _ = bot
                    .edit_message_text(
                        msg.chat().id,
                        msg.id(),
                        "✅ <b>Berhasil!</b> \
                         Seluruh warn member \
                         di grup ini telah di-reset.",
                    )
                    .parse_mode(ParseMode::Html)
                    .await;
            }

            Err(err) => {
                println!("❌ [ERROR RESET ALL WARNS] {:?}", err);
            }
        }

        return Ok(());
    }

    // ==========================================================
    // ==========================================================
    // 8. CANCEL RESET ALL WARNS
    // ==========================================================
    // ==========================================================

    if data.starts_with("cancel_reset_all_warn") {
        let _ = bot.answer_callback_query(q.id.clone()).await;

        let _ = bot
            .edit_message_text(msg.chat().id, msg.id(), "❌ Proses reset warn dibatalkan.")
            .parse_mode(ParseMode::Html)
            .await;

        return Ok(());
    }

    // ==========================================================
    // UNKNOWN CALLBACK
    // ==========================================================

    println!("⚠️ [CALLBACK UNKNOWN] {}", data);

    let _ = bot.answer_callback_query(q.id).await;

    Ok(())
}
